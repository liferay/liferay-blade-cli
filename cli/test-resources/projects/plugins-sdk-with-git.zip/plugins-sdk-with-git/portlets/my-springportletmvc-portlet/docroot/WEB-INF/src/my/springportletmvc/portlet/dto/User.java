package my.springportletmvc.portlet.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author ngriffin
 */
public class User implements Serializable {

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	private static final long serialVersionUID = 1113488483222411111L;

	@NotNull
	@Pattern(message="must-not-be-only-whitespace", regexp=".*[\\S].*")
	@Size(min=1, max=50)
	private String firstName;

	@NotNull
	@Pattern(message="must-not-be-only-whitespace", regexp=".*[\\S].*")
	@Size(min=1, max=50)
	private String lastName;

}