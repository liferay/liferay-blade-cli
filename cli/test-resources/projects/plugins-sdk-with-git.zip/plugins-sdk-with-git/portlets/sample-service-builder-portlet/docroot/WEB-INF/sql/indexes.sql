create index IX_DEC05F3B on SSB_Foo (field2);
create index IX_56640885 on SSB_Foo (uuid_);
create index IX_ED0BE683 on SSB_Foo (uuid_, companyId);
create unique index IX_725231C5 on SSB_Foo (uuid_, groupId);