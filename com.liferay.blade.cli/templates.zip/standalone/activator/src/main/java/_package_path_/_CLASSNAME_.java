package _package_;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class _CLASSNAME_ implements BundleActivator {

	@Override
	public void start(BundleContext context) throws Exception {
	}

	@Override
	public void stop(BundleContext context) throws Exception {
	}

}