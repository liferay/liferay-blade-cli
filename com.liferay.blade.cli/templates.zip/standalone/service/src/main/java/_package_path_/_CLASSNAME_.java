package _package_;

import _SERVICE_FULL_;

import org.osgi.service.component.annotations.Component;

@Component(
	immediate = true,
	property = {
	},
	service = _SERVICE_SHORT_.class
)
public class _CLASSNAME_ implements _SERVICE_SHORT_ {


}